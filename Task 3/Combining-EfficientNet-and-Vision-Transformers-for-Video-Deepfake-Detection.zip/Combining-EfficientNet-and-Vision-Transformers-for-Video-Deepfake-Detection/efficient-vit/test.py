import matplotlib.pyplot as plt
from sklearn import metrics
from sklearn.metrics import auc
from sklearn.metrics import accuracy_score, confusion_matrix
import os
import cv2
import numpy as np
import torch
from torch import nn, einsum

from sklearn.metrics import f1_score



import torch.nn as nn
import torch.nn.functional as F
from functools import partial
from efficient_vit import EfficientViT
import glob
from os import cpu_count
import json
from multiprocessing.pool import Pool
import pandas as pd
from tqdm import tqdm
from multiprocessing import Manager
from utils import custom_round, custom_video_round

import yaml
import argparse


MODELS_DIR = "models"
BASE_DIR = "../../deep_fakes"
DATA_DIR = os.path.join(BASE_DIR, "dataset")
TEST_DIR = os.path.join(DATA_DIR, "test_set")
OUTPUT_DIR = os.path.join(MODELS_DIR, "tests")

TEST_LABELS_PATH = os.path.join(BASE_DIR, "dataset/dfdc_test_labels.csv")



if not os.path.exists(MODELS_DIR):
    os.makedirs(MODELS_DIR)

if not os.path.exists(OUTPUT_DIR):
    os.makedirs(OUTPUT_DIR)


def save_roc_curves(correct_labels, preds, model_name, accuracy, f1):
  plt.figure(1)
  plt.plot([0, 1], [0, 1], 'k--')

  fpr, tpr, th = metrics.roc_curve(correct_labels, preds)

  model_auc = auc(fpr, tpr)


  plt.plot(fpr, tpr, label="Model_"+ model_name + ' (area = {:.3f})'.format(model_auc))

  plt.xlabel('False positive rate')
  plt.ylabel('True positive rate')
  plt.title('ROC curve')
  plt.legend(loc='best')
  plt.savefig("/content/ROC.jpg")
  plt.clf()


from tensorflow.keras.preprocessing.image import ImageDataGenerator
import torch
if torch.cuda.is_available():
    device = torch.device('cuda')
else:
    device = torch.device('cpu')

result = []
class_array = []
dataGenerator = ImageDataGenerator()
test_generator = dataGenerator.flow_from_directory(
        '/content/cropped',
        target_size=(224, 224),
        batch_size=1,
        class_mode='binary',
        subset='training')



# Main body
if __name__ == "__main__":
    
    parser = argparse.ArgumentParser()
    
    parser.add_argument('--workers', default=10, type=int,
                        help='Number of data loader workers.')
    parser.add_argument('--model_path', default='', type=str, metavar='PATH',
                        help='Path to model checkpoint (default: none).')
    parser.add_argument('--dataset', type=str, default='DFDC', 
                        help="Which dataset to use (Deepfakes|Face2Face|FaceShifter|FaceSwap|NeuralTextures|DFDC)")
    parser.add_argument('--max_videos', type=int, default=-1, 
                        help="Maximum number of videos to use for training (default: all).")
    parser.add_argument('--config', type=str, 
                        help="Which configuration to use. See into 'config' folder.")
    parser.add_argument('--efficient_net', type=int, default=0, 
                        help="Which EfficientNet version to use (0 or 7, default: 0)")
    parser.add_argument('--frames_per_video', type=int, default=30, 
                        help="How many equidistant frames for each video (default: 30)")
    parser.add_argument('--batch_size', type=int, default=32, 
                        help="Batch size (default: 32)")
    
    opt = parser.parse_args()
    print(opt)

    with open(opt.config, 'r') as ymlfile:
        config = yaml.safe_load(ymlfile)

    if opt.efficient_net == 0:
        channels = 1280
    else:
        channels = 2560

    if os.path.exists(opt.model_path):
        model = EfficientViT(config=config, channels=channels, selected_efficient_net = opt.efficient_net)
        model.load_state_dict(torch.load(opt.model_path, map_location=torch.device('cpu')))
        model.eval()
        model = model.cuda()
        #model.to(device)
    else:
        print("No model found.")
        exit()

    model_name = os.path.basename(opt.model_path)

    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)
        
    
    preds = []
    correct_test_labels = []

    #bar = Bar('Predicting', max=len(videos))




    for i in range(len(test_generator.labels)):
        X, y = test_generator.next()

        
        faces = torch.tensor(np.asarray(X))
        if faces.shape[0] == 0:
            continue
        correct_test_labels.append(y)
        faces = np.transpose(faces, (0, 3, 1, 2))
        faces = faces.cuda().float()
        
        pred = model(faces)
        prediction = torch.sigmoid(pred).cpu().detach().numpy()[0]
        preds.append(round(prediction[0]))
                #else preds.append(torch.sigmoid(pred))
        


    #accuracy = accuracy_score(np.asarray(preds).round(), correct_test_labels)
    accuracy = accuracy_score(np.asarray(preds), correct_test_labels)

    f1 = f1_score(correct_test_labels, custom_round(np.asarray(preds)))
    print(model_name, "Test Accuracy:", accuracy, "F1", f1)
    print(confusion_matrix(correct_test_labels,preds ))
    save_roc_curves(correct_test_labels, preds, model_name, accuracy, f1)
